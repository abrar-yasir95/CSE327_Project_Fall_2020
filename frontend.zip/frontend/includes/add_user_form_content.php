       <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    
                    <div class="page-bar">
                        
                        
                    </div>
                    <!-- END PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12 ">
                            <!-- BEGIN VALIDATION STATES-->
                            <div class="portlet light portlet-fit portlet-form ">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject font-dark sbold uppercase">Add User</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body custom_form">
                                    <!-- BEGIN FORM-->
                                    <form action="#" id="form_sample_3" class="form-horizontal custom_form2">
                                        <div class="form-body">
                                            
                                            <div class="form-group ">
                                              
                                                <div class="col-md-5 ">
                                                    <input type="text" name="First Name" data-required="1" class="form-control field_custom" placeholder="First name" /> </div>
                                                     <div class="col-md-5">
                                                    <input type="text" name="Last name" data-required="1" class="form-control field_custom" placeholder="Last Name" /> </div>
                                            </div>
                                           <div class="form-group">
                                              
                                                <div class="col-md-10">
                                                    <input name="BD Number" type="text" class="form-control field_custom" placeholder="BD Number" /> </div>
                                            </div>
                                               <div class="form-group">
                                              
                                                <div class="col-md-10">
                                                    <input name="password" type="password" class="form-control field_custom" placeholder="password" /> </div>
                                            </div>
                                                   <div class="form-group">
                                                
                                                <div class="col-md-10">
                                                    <select class="form-control field_custom1 classic" name="Select_Rank" placeholder="Select Rank">
                                                        <option value="">Select Rank</option>
                                                       <option value="Flying officer">Flying officer</option>
														  <option value="Flight lieutenant">Flight lieutenant</option>
														  <option value="Wing commander">Wing commander</option>
														  <option value="Group captain">Group captain</option>
														  <option value="Air commodore">Air commodore </option>
														  <option value="Air vice marshal">Air vice marshal </option>
														  <option value="Air marshal">Air marshal </option>
                                                    </select>
                                                </div>
                                            </div>
                                                       <div class="form-group">
                                                
                                                <div class="col-md-10">
                                                    <select class="form-control field_custom1 classic" name="Posting_Base">
                                                        <option value="">Posting Base</option>
                                                        <option value="BAF BSR">BAF BSR</option>
                                                        <option value="BAF BBD">BAF BBD</option>
                                                        <option value="BAF MTR">BAF MTR</option>
                                                        <option value="BAF ZHR">BAF ZHR</option>
                                                        <option value="BAF PKP">BAF PKP</option>
                                                        <option value="BAF COX'S">BAF COX'S</option>
                                                    </select>
                                                </div>
                                            </div>
                                                                <div class="form-group">
                                                
                                                <div class="col-md-10">
                                                    <select class="form-control field_custom1 classic" name="Eligibile_Quater_Type">
                                                        <option value="">Eligibile Quater Type</option>
                                                        <option value="Option 1">One</option>
                                                        <option value="Option 2">two</option>
                                                        <option value="Option 3">three</option>
                                                        <option value="Option 4">four</option>
                                                    </select>
                                                </div>
                                            </div>
                                                
                                                     <div class="form-group">
                                            
                                                <div class="col-md-10">
                                                    <div class="input-group date date-picker" data-date-format="dd-mm-yyyy">
                                                        <input type="text" class="form-control field_custom3" readonly name="datepicker" placeholder="Date Of Commision">
                                                        <span class="input-group-btn">
                                                            <button class="btn default custom_form_icon" type="button">
                                                                <i class="fa fa-calendar"></i>
                                                            </button>
                                                        </span>
													</div>
                                                </div>
                                            </div>
                                                
                                            
                                                 <div class="form-group">
                                              
                                                <div class="col-md-10">
                                                    <input name="Point_Carrys_On" type="text" class="form-control field_custom" placeholder="Point Carrys On" /> </div>
                                            </div>
                                             <div class="form-group">
                                                <div class="col-md-10">
                                                    <input name="Authentication_Number" type="text" class="form-control field_custom" placeholder="Authentication Number" /> </div>
                                            </div>
                                             
                                            <div class="form-group">
                                              
                                                <div class="col-md-10">
                                                    <input name="Number_of_Child" type="text" class="form-control field_custom" placeholder="Number of Child" /> </div>
                                            </div>
                                            <div class="form-group">
                                                
                                                <div class="col-md-10 ">
                                                    <select class="form-control field_custom1 classic" name="Select_Role" placeholder="gfhgfhf" >
                                                        <option value="">Select Role</option>
                                                        <option value="Option 1">AOC</option>
                                                        <option value="Option 2">OC</option>
                                                        <option value="Option 3">AC</option>
                                                        <option value="Option 4">System User</option>
                                                        <option value="Option 4">Regular User</option>
                                                    </select>
                                                </div>
                                            </div>
                                       
                                            
                                        </div>
                                        <div class="form-actions custom_button_div">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9 ">
                                                    <button type="submit" class="btn custom_button1">Submit</button>
                                                    <button type="button" class="btn custom_button2">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- END FORM-->
                                </div>
                                <!-- END VALIDATION STATES-->
                            </div>
                        </div>
                    </div>
                    
                     
                       
                    
                    
                    </div>
                </div>
                <!-- END CONTENT BODY -->
            </div>
                        <!-- END CONTENT -->