    <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- END PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light portlet-fit ">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="icon-settings font-red"></i>
                                        <span class="caption-subject font-red sbold uppercase">allotment latter</span>
                                    </div>
                              
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                           
                                            
                                        </div>
                                    </div>
                                    <table class="table table-striped table-hover table-bordered" id="sample_editable_1">
                                        <thead>
                                            <tr>
                                                <th>Serial Number</th>
                                                <th> File Name</th>
                                         
                                                 <th> Action </th>
                                                 
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td> 1 </td>
                                                <td>file.pdf</td>
                                           
                                                <td>
                                                    <a class="edit" href="javascript:;"> <button class="btn btn-primary edit_custom_blue">Edit </button></a>
                                                    <a class="delete" href="javascript:;"> <button class="btn btn-danger edit_custom_red">Delete</button> </a>
                                                </td>
                                               
                                            </tr>
                                                 <tr>
                                                <td> 2 </td>
                                                <td>file.pdf</td>
                                           
                                                <td>
                                                    <a class="edit" href="javascript:;"> <button class="btn btn-primary edit_custom_blue">Edit </button></a>
                                                    <a class="delete" href="javascript:;"> <button class="btn btn-danger edit_custom_red">Delete</button> </a>
                                                </td>
                                               
                                            </tr>
                                                  <tr>
                                                <td> 3</td>
                                                <td>file.pdf</td>
                                           
                                                <td>
                                                    <a class="edit" href="javascript:;"> <button class="btn btn-primary edit_custom_blue">Edit </button></a>
                                                    <a class="delete" href="javascript:;"> <button class="btn btn-danger edit_custom_red">Delete</button> </a>
                                                </td>
                                               
                                            </tr>
                                                  <tr>
                                                <td> 4 </td>
                                                <td>file.pdf</td>
                                           
                                                <td>
                                                    <a class="edit" href="javascript:;"> <button class="btn btn-primary edit_custom_blue">Edit </button></a>
                                                    <a class="delete" href="javascript:;"> <button class="btn btn-danger edit_custom_red">Delete</button> </a>
                                                </td>
                                               
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->