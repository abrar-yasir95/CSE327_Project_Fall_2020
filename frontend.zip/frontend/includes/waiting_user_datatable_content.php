      <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
   
                    <!-- END PAGE HEADER-->
                
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase">Wainting user information</span>
                                    </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover" id="sample_1">
                                        <thead>
                                            <tr>
                                            <th>Ser. No.</th>
                                                <th>Rank</th>
                                                <th>Name</th>
                                                <th>BD No</th>
                                                <th>Branch</th>
                                                <th>current point</th>
                                                <th>Existing svc/gvt<br> qtr & type</th>
                 								<th > date of offering<br> 1st</th>
                								<th> date of offering<br> 2nd  </th>
 												<th>Dt/Unit/Sqn<br> contact Tel No<br> offr/Res any offr</th>
                								<th>Rmks</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                               <tr>
                                                 <td>1</td>
												  <td>Air vice marshal</td>
												  <td>Faruk Hossain</td>
												  <td>9875</td>
												  <td>Gdp</td>
												  <td>0</td>
												  <td>Apartment</td>
												  <td>11 july 2015</td>
												   <td>11 july 2019</td>
												  <td>Dhaka</td>
												  <td>0</td>
                                            </tr>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->