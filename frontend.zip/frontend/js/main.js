$('.carousel').carousel({
  interval: 4000,
  pause: "false"
});

